# VisSpeech dataset.

VisSpeech is an audio-visual speech recognition dataset.

## Statistics

VisSpeech consists of 508 segments from 495 unique videos. 
The average transcript length is 12.2 words and average segment duration is 4.3 seconds

## Usage

VisSpeech is to be used as a test set for zero-shot evaluation of audio-visual speech recognition models.
The transcripts only consist of lowercase characters + the apostrophe. All punctuation including hyphens has been removed. All punctuation should therefore be removed from predictions before evaluating on VisSpeech.

The VisSpeech.csv file contains one sample per line, with the data in the following order:
key,yt_id,start_time,end_time,annotation

## License

Copyright 2022 Valentin Gabeur

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

